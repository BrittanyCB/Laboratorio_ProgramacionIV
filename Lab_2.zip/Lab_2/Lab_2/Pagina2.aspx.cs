﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab_2
{
    delegate double Calculo(double A);
    public partial class Pagina2 : System.Web.UI.Page
    {
     
        protected void Page_Load(object sender, EventArgs e)
        {
            txtNombre.Text = Session["Usuario"].ToString();
        }

        protected void btn_Calcular_Click(object sender, EventArgs e)
        {
            Func<double, double> fn1 = Calcular.doblarnumero;
            double numero = Convert.ToDouble(txtNumero.Text);
            double Resultado = fn1(numero);
            txt_Resultado.Text = Resultado.ToString();

            Action<string> fn2 = Calcular.definirBitacora;
            string guardar = String.Format("Se multiplica {0} con 2 y da como resultado: {1}", numero, Resultado);
            fn2(guardar);

        }
    }
}