﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Lab_2
{
    public class Calcular
    {
        public static double doblarnumero(double n1)
        {
            return n1 * 2;
        }

        public static void definirBitacora(string Guardar)
        {
            using (StreamWriter objStrem = new StreamWriter(@"C:\Bitacora\bitacoraResultado.txt", true))
            {
                objStrem.WriteLine(Guardar);
                objStrem.Flush();
            }
           
        }
    }
}