﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Capa_Datos.Tablas;
using System.Configuration;

namespace Capa_Datos
{
    public class ManejoBD
    {
        SqlConnection conexion;
        SqlCommand comando;
        string cadenacon = "Data Source=DESKTOP-VSL7C3P;Initial Catalog = Ferreteria; Integrated Security = True";
        //ConfigurationManager.ConnectionStrings["ConexionLab"].ConnectionString;

        public List<CatDisponible> listadoDisp()
        {
            SqlDataReader datoLeido;
            List<CatDisponible> listReturn;


            conexion = new SqlConnection();
            conexion.ConnectionString = cadenacon;

            comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Select * from CatDisponible";
            comando.CommandType = System.Data.CommandType.Text;
            comando.CommandTimeout = 0;

            conexion.Open();
            datoLeido = comando.ExecuteReader();

            listReturn = new List<CatDisponible>();
            while (datoLeido.Read())
            {

                CatDisponible objDisponible = new CatDisponible(); //Creamo el objeto genero
                objDisponible.IDDisp = datoLeido.GetInt32(0);
                objDisponible.Descripcion = datoLeido.GetString(1);
                listReturn.Add(objDisponible);

            }
            return listReturn;
        }
        public bool registrarHerramienta(Herramientas objHerramienta)
        {
            int control = -1;
            bool respuesta = false;

            using (SqlConnection cnx = new SqlConnection(cadenacon))
            {
                comando = new SqlCommand();
                comando.Connection = cnx;
                comando.CommandType = System.Data.CommandType.Text;
                comando.CommandText = "Insert into Herramientas (IDHerramienta,NombreHerramienta,MarcaHerramienta,PrecioHerramienta) " +
                                      " Values (@IDHerramienta,@NombreHerramienta,@MarcaHerramienta,@PrecioHerramienta)";


                comando.Parameters.Add(new SqlParameter("@IDHerramienta", objHerramienta.IDHerramienta));

                comando.Parameters.Add(new SqlParameter("@NombreHerramienta", objHerramienta.NombreHerramienta));

                comando.Parameters.Add(new SqlParameter("@MarcaHerramienta", objHerramienta.MarcaHerramienta));

                comando.Parameters.Add(new SqlParameter("@PrecioHerramienta", objHerramienta.PrecioHerramienta));

                cnx.Open();

                control = comando.ExecuteNonQuery();

            }

            if (control > 0)
            {
                respuesta = true;
            }

            return respuesta;

        }
        public bool actualizarHerramienta(Herramientas objHerramienta)
        {
            int controlA = -1;
            bool respuestaA = false;

            using (SqlConnection cnx = new SqlConnection(cadenacon))
            {
                comando = new SqlCommand();
                comando.Connection = cnx;
                comando.CommandType = System.Data.CommandType.Text;
                comando.CommandText = "Update Herramientas SET @NombreHerramienta=NombreHerramienta,@MarcaHerramienta=MarcaHerramienta,"+
                    "@PrecioHerramienta=PrecioHerramienta Where @IDHerramienta =IDHerramienta";

                comando.Parameters.Add(new SqlParameter("@IDHerramienta", objHerramienta.IDHerramienta));

                comando.Parameters.Add(new SqlParameter("@NombreHerramienta", objHerramienta.NombreHerramienta));

                comando.Parameters.Add(new SqlParameter("@MarcaHerramienta", objHerramienta.MarcaHerramienta));

                comando.Parameters.Add(new SqlParameter("@PrecioHerramienta", objHerramienta.PrecioHerramienta));

                cnx.Open();

                controlA = comando.ExecuteNonQuery();

            }

            if (controlA > 0)
            {
                respuestaA = true;
            }

            return respuestaA;

            
        }
        public bool eliminarHerramienta(Herramientas objHerramienta)
        {
            int controlB = -1;
            bool respuestaB = false;

            using (SqlConnection cnx = new SqlConnection(cadenacon))
            {
                comando = new SqlCommand();
                comando.Connection = cnx;
                comando.CommandType = System.Data.CommandType.Text;
                comando.CommandText = "Delete FROM Herramientas " +
                                      "Where IDHerramienta =@IDHerramienta";


                comando.Parameters.Add(new SqlParameter("@IDHerramienta", objHerramienta.IDHerramienta));

                cnx.Open();

                controlB = comando.ExecuteNonQuery();

            }

            if (controlB > 0)
            {
                respuestaB = true;
            }

            return respuestaB;


        }

    }
}
